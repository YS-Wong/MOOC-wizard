//"elements" are giving points; 
//"elements1" are giving commemts;

if(document.getElementsByClassName('j-evaluate').length > 0){
	var elements = document.getElementsByClassName('j-select');
	var args = 0;
	while(args < elements.length - 1){
		if(elements[args].value > elements[args+1].value){
			elements[args].click();
		}
		args++;
	}
	elements[args].click();
	var elements1 = document.getElementsByClassName('j-textarea inputtxt');
	var comments = ["good. ","very nice. ","exelent! ","well done. ","super! "];
	args1 = 1;
	while(args1 < elements1.length){
		elements1[args1].value = comments[Math.floor(Math.random() * 5)];
		args1++;
	}
}
