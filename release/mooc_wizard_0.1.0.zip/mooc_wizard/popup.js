
'use strict';

let evaluate = document.getElementById('evaluate');

evaluate.onclick = function(element) {
  chrome.tabs.executeScript(
    {file: 'contentScript.js'});
};
